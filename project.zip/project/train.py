import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mlp import MLP
from dataset import generate_dataset


def plot_loss(train_loss, val_loss):
    plt.figure(figsize=(10, 6))
    plt.plot(train_loss, label='Training Loss', linewidth=2, marker='o')
    plt.plot(val_loss, label='Validation Loss', linewidth=2, marker='s')
    plt.xlabel('Epoch')
    plt.ylabel('Mean Squared Error')
    plt.title('MLP Training Convergence')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    os.makedirs('results', exist_ok=True)
    plt.savefig('results/loss_curve.png', dpi=300)
    plt.close()
    print("Loss curve saved to results/loss_curve.png")

print("=" * 60)
print("MLP TRAINING - Hardware-Software Co-Design Project")
print("=" * 60)

# Generate dataset
print("\n[1] Generating dataset...")
X_train, y_train, X_test, y_test = generate_dataset()

# Create model
print("\n[2] Creating MLP model...")
model = MLP(
    layer_sizes=[10, 256, 128, 64, 1],
    lr=0.01,
    seed=42
)

# Count parameters
total_params = sum(W.size + b.size for W, b in zip(model.weights, model.biases))
print(f"Total parameters: {total_params:,}")

# Train
print("\n[3] Training...")
train_loss, val_loss = model.train(X_train, y_train, X_test, y_test, epochs=10)

# Plot loss curves
plot_loss(train_loss, val_loss)

# Save
print("\n[4] Saving model...")
model.save('models/mlp_trained.npz')

print("\nTraining complete!")
print(f"Final training loss: {train_loss[-1]:.6f}")
print(f"Final validation loss: {val_loss[-1]:.6f}")
