import numpy as np
import time
import os
import csv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mlp import MLP


def visualize_predictions(model, X_test, y_test, n_samples=5):
    """Show predictions vs actual values for the first n_samples test points."""
    preds = model.infer(X_test)

    plt.figure(figsize=(12, 6))
    plt.scatter(range(n_samples), y_test[0, :n_samples],
                label='Actual', s=100, color='blue', marker='o')
    plt.scatter(range(n_samples), preds[0, :n_samples],
                label='Predicted', s=100, color='red', marker='x')
    plt.xlabel('Sample Index')
    plt.ylabel('Target Value')
    plt.title('MLP Predictions vs Actual Values')
    plt.legend()
    plt.grid(True, alpha=0.3)
    os.makedirs('results', exist_ok=True)
    plt.savefig('results/predictions.png', dpi=300)
    plt.close()
    print("Predictions plot saved to results/predictions.png")


def print_results_table(naive_time, np_time, fpga_time):
    print("\n" + "=" * 70)
    print("  PERFORMANCE COMPARISON")
    print("=" * 70)
    print(f"{'Platform':<30} {'Time (ms)':<15} {'Speedup':<10}")
    print("-" * 70)
    print(f"{'Naive CPU (Python loops)':<30} {naive_time:<15.2f} {'1.00x':<10}")
    print(f"{'NumPy CPU (BLAS)':<30} {np_time:<15.4f} {naive_time/np_time:.2f}x")
    print(f"{'FPGA (16x16 @100MHz)':<30} {fpga_time:<15.4f} {naive_time/fpga_time:.2f}x")
    print("=" * 70)

print("=" * 60)
print("MLP INFERENCE BENCHMARK")
print("=" * 60)

# Load model
model = MLP.load('models/mlp_trained.npz')
print(f"Model loaded: {model.layer_sizes}")

# Generate test input
x = np.random.randn(10, 1).astype(np.float64)


# --- Platform 1: Naive CPU ---
def naive_inference(model, x):
    a = x
    for i, (W, b) in enumerate(zip(model.weights, model.biases)):
        M, N = W.shape
        out = np.zeros((M, 1))
        for row in range(M):
            acc = b[row, 0]
            for col in range(N):
                acc += W[row, col] * a[col, 0]
            out[row, 0] = acc
        a = np.maximum(0, out) if i < len(model.weights) - 1 else out
    return a


print("\n[1] Naive CPU (Python loops)...")
times = []
for _ in range(3):
    t0 = time.perf_counter()
    _ = naive_inference(model, x)
    times.append((time.perf_counter() - t0) * 1000)
naive_time = np.min(times)
print(f"    Time: {naive_time:.2f} ms")

# --- Platform 2: NumPy CPU ---
print("\n[2] NumPy CPU (BLAS)...")
times = []
for _ in range(100):
    t0 = time.perf_counter()
    _ = model.infer(x)
    times.append((time.perf_counter() - t0) * 1000)
np_time = np.mean(times)
print(f"    Time: {np_time:.4f} ms")

# --- Platform 3: FPGA (Cycle Model) ---
print("\n[3] FPGA (16x16 Systolic Array @ 100MHz)...")


def fpga_gemv_cycles(M, N):
    PE_COLS = 16
    SETUP = 15
    DRAIN = 16
    passes = max(1, (N + PE_COLS - 1) // PE_COLS)
    return passes * M + SETUP + DRAIN


# Layer sizes: 10->256->128->64->1
layer_pairs = [(10, 256), (256, 128), (128, 64), (64, 1)]
total_cycles = 0
for N, M in layer_pairs:  # N=input, M=output
    total_cycles += fpga_gemv_cycles(M, N)

CLK_PERIOD_NS = 10  # 100 MHz
fpga_time = (total_cycles * CLK_PERIOD_NS) / 1000.0  # ms
print(f"    Total cycles: {total_cycles}")
print(f"    Time: {fpga_time:.4f} ms")

# --- Summary ---
print_results_table(naive_time, np_time, fpga_time)

# --- Predictions visualization ---
print("\n[4] Visualizing predictions on test set...")
if os.path.exists('data/X_test.npy') and os.path.exists('data/y_test.npy'):
    X_test = np.load('data/X_test.npy')
    y_test = np.load('data/y_test.npy')
    visualize_predictions(model, X_test, y_test, n_samples=5)
else:
    print("    Skipped: data/X_test.npy or data/y_test.npy not found (run dataset.py first).")

# --- Save results to CSV ---
os.makedirs('results', exist_ok=True)
with open('results/performance.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['platform', 'time_ms', 'speedup_vs_naive'])
    writer.writerow(['Naive CPU', f'{naive_time:.6f}', '1.0'])
    writer.writerow(['NumPy CPU', f'{np_time:.6f}', f'{naive_time/np_time:.4f}'])
    writer.writerow(['FPGA (16x16 systolic @ 100MHz)', f'{fpga_time:.6f}', f'{naive_time/fpga_time:.4f}'])
print("\nResults saved to results/performance.csv")
