import numpy as np
import os


class MLP:
    def __init__(self, layer_sizes=[10, 256, 128, 64, 1], lr=0.01, seed=42):
        self.layer_sizes = list(layer_sizes)
        self.lr = lr
        np.random.seed(seed)

        self.weights = []
        self.biases = []

        for i in range(len(self.layer_sizes) - 1):
            fan_in = self.layer_sizes[i]
            fan_out = self.layer_sizes[i + 1]
            # He initialization
            W = np.random.randn(fan_out, fan_in) * np.sqrt(2.0 / fan_in)
            b = np.zeros((fan_out, 1))
            self.weights.append(W)
            self.biases.append(b)

    def relu(self, x):
        return np.maximum(0, x)

    def relu_derivative(self, x):
        return (x > 0).astype(float)

    def forward(self, x):
        activations = [x]
        pre_activations = []
        a = x

        for i, (W, b) in enumerate(zip(self.weights, self.biases)):
            z = W @ a + b
            pre_activations.append(z)
            if i < len(self.weights) - 1:
                a = self.relu(z)  # Hidden layer: ReLU
            else:
                a = z  # Output layer: Linear
            activations.append(a)

        return activations, pre_activations

    def backward(self, activations, pre_activations, y_true):
        batch_size = y_true.shape[1]
        grad_W = []
        grad_b = []

        y_pred = activations[-1]
        delta = (y_pred - y_true) / batch_size

        for l in reversed(range(len(self.weights))):
            if l < len(self.weights) - 1:
                delta = delta * self.relu_derivative(pre_activations[l])

            a_prev = activations[l]
            dW = delta @ a_prev.T
            db = np.sum(delta, axis=1, keepdims=True)

            grad_W.insert(0, dW)
            grad_b.insert(0, db)

            if l > 0:
                delta = self.weights[l].T @ delta

        return grad_W, grad_b

    def update(self, grad_W, grad_b):
        for i in range(len(self.weights)):
            self.weights[i] -= self.lr * grad_W[i]
            self.biases[i] -= self.lr * grad_b[i]

    def train_step(self, x_batch, y_batch):
        activations, pre_activations = self.forward(x_batch)
        loss = np.mean((activations[-1] - y_batch) ** 2) / 2.0
        grad_W, grad_b = self.backward(activations, pre_activations, y_batch)
        self.update(grad_W, grad_b)
        return loss

    def train(self, X_train, y_train, X_val, y_val, epochs=10, batch_size=64):
        n_samples = X_train.shape[1]
        train_losses = []
        val_losses = []

        for epoch in range(epochs):
            # Shuffle
            perm = np.random.permutation(n_samples)
            X_shuf = X_train[:, perm]
            y_shuf = y_train[:, perm]

            epoch_loss = 0
            n_batches = 0
            for i in range(0, n_samples, batch_size):
                xb = X_shuf[:, i:i + batch_size]
                yb = y_shuf[:, i:i + batch_size]
                epoch_loss += self.train_step(xb, yb)
                n_batches += 1

            train_losses.append(epoch_loss / n_batches)

            # Validation
            pred = self.infer(X_val)
            val_losses.append(np.mean((pred - y_val) ** 2) / 2.0)

            print(f"Epoch {epoch+1}: train_loss={train_losses[-1]:.6f}, val_loss={val_losses[-1]:.6f}")

        return train_losses, val_losses

    def infer(self, x):
        if x.ndim == 1:
            x = x.reshape(-1, 1)
        a = x
        for i, (W, b) in enumerate(zip(self.weights, self.biases)):
            z = W @ a + b
            if i < len(self.weights) - 1:
                a = self.relu(z)
            else:
                a = z
        return a

    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        np.savez(
            path,
            weights=np.array(self.weights, dtype=object),
            biases=np.array(self.biases, dtype=object),
            layer_sizes=np.array(self.layer_sizes),
            lr=self.lr,
        )

    def load_(self, path):
        """Instance-level load (mutates self)."""
        data = np.load(path, allow_pickle=True)
        self.weights = list(data['weights'])
        self.biases = list(data['biases'])
        self.layer_sizes = list(data['layer_sizes'])
        if 'lr' in data:
            self.lr = float(data['lr'])
        return self

    @classmethod
    def load(cls, path):
        """Classmethod load: MLP.load('path.npz') -> returns a new MLP instance."""
        data = np.load(path, allow_pickle=True)
        layer_sizes = list(data['layer_sizes'])
        lr = float(data['lr']) if 'lr' in data else 0.01
        model = cls(layer_sizes=layer_sizes, lr=lr)
        model.weights = list(data['weights'])
        model.biases = list(data['biases'])
        return model
