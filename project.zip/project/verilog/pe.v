module pe (
    input  wire           clk,
    input  wire           rst_n,
    input  wire signed [15:0] a_in,
    input  wire signed [15:0] b_in,
    output reg  signed [31:0] mac_o,
    output wire signed [15:0] a_out,
    output wire signed [15:0] b_out
);
    assign a_out = a_in;
    assign b_out = b_in;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            mac_o <= 32'd0;
        else
            mac_o <= mac_o + a_in * b_in;
    end
endmodule
