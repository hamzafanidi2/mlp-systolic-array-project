module systolic_array (
    input  wire               clk,
    input  wire               rst_n,
    input  wire signed [15:0] a_in [15:0],
    input  wire signed [15:0] b_in [15:0],
    output wire signed [31:0] result_o [15:0]
);
    wire signed [15:0] a_wire [15:0][15:0];
    wire signed [15:0] b_wire [15:0][15:0];
    wire signed [31:0] mac_wire [15:0][15:0];

    genvar i, j;
    generate
        for (i = 0; i < 16; i = i + 1) begin : rows
            for (j = 0; j < 16; j = j + 1) begin : cols
                assign a_wire[i][j] = (j == 0) ? a_in[i] : a_wire[i][j-1];
                assign b_wire[i][j] = (i == 0) ? b_in[j] : b_wire[i-1][j];

                pe pe_inst (
                    .clk(clk),
                    .rst_n(rst_n),
                    .a_in(a_wire[i][j]),
                    .b_in(b_wire[i][j]),
                    .mac_o(mac_wire[i][j]),
                    .a_out(),
                    .b_out()
                );
            end
        end

        for (j = 0; j < 16; j = j + 1) begin : output_capture
            assign result_o[j] = mac_wire[15][j];
        end
    endgenerate
endmodule
