`timescale 1ns/1ps

module testbench;
    reg               clk;
    reg               rst_n;
    reg  signed [15:0] a_in [15:0];
    reg  signed [15:0] b_in [15:0];
    wire signed [31:0] result_o [15:0];

    integer i;

    systolic_array dut (
        .clk(clk),
        .rst_n(rst_n),
        .a_in(a_in),
        .b_in(b_in),
        .result_o(result_o)
    );

    // Clock generation: 100 MHz -> 10 ns period
    always #5 clk = ~clk;

    initial begin
        clk   = 0;
        rst_n = 0;
        for (i = 0; i < 16; i = i + 1) begin
            a_in[i] = 16'sd0;
            b_in[i] = 16'sd0;
        end

        // Hold reset for a couple of cycles
        #12 rst_n = 1;

        // Drive simple test vectors
        #10;
        for (i = 0; i < 16; i = i + 1) begin
            a_in[i] = i + 1;      // 1..16
            b_in[i] = 2;          // constant weight
        end

        // Let data propagate through the 16x16 array
        // (setup + drain latency ~ 15 + 16 cycles)
        #400;

        $display("=========================================");
        $display("Systolic Array Testbench Results");
        $display("=========================================");
        for (i = 0; i < 16; i = i + 1) begin
            $display("result_o[%0d] = %0d", i, result_o[i]);
        end
        $display("=========================================");
        $display("Simulation finished at time %0t", $time);

        $finish;
    end

    initial begin
        $dumpfile("systolic_array.vcd");
        $dumpvars(0, testbench);
    end
endmodule
